#!/bin/bash

go build -o ./bin/web-server ./cmd/web-server/golang-web-server.go